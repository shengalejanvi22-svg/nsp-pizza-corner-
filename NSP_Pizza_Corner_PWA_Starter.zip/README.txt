NSP PIZZA CORNER — INSTALLABLE PWA STARTER

CONTENTS
- index.html: existing POS prototype with PWA manifest/service worker references
- manifest.webmanifest: app name, display mode and icons
- sw.js: caches the app shell for basic offline loading
- icons/: 192px and 512px app icons

IMPORTANT LIMITATIONS
1. This makes the current prototype PWA-ready; it does not add cloud database or multi-device sync.
2. The existing POS uses browser-local storage. Data may remain only in the browser/profile/device and is not a safe replacement for regular backups.
3. The service worker and installability need the app to be served from HTTPS (or localhost for testing). Opening index.html directly as a file will not enable PWA installation/offline caching.
4. Thermal USB printing still uses the browser print dialog. Direct printer control/automatic kitchen ticket printing needs printer-specific integration and testing.

HOW TO HOST FOR FREE/LOW COST
- Put all files in this folder into a GitHub repository.
- Enable GitHub Pages for the repository and publish from the main branch/root.
- Open the resulting HTTPS site URL in Chrome on Windows and Android.
- Windows Chrome: menu ⋮ > Cast, save, and share > Install page as app (wording may vary).
- Android Chrome: menu ⋮ > Install app or Add to Home screen.

FOR REAL RESTAURANT USE
Add a backend/cloud database (for example, Supabase or Firebase), user login/roles, backups, and transaction-safe inventory logic before relying on it for live sales. Never assume this PWA starter synchronizes data across devices.
